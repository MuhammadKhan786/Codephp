<!DOCTYPE html>
<html>
<head>
	<title>Single Post</title>
</head>
<body>
	<h1>
		<?php
            echo $Post->title;
		 ?>

	</h1>
	<p>
		<?php 
         echo $Post->body;
		?>

	</p>

</body>
</html>