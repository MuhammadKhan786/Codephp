<!DOCTYPE html>
<html>
<head>
	<title>My Posts Here</title>
</head>
<body>
	<ul>
<?php 
echo 'My posts will be here..';

foreach ($Posts as $post) {
	
	echo "<li><a href='post/$post->id'".$post->title."</a></li>";

	# code...
}

?>
</ul>
</body>
</html>