<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PostController extends Controller
{
    //
    public function index()
    {
      $Posts=\App\Post::all();
      return view('Post.index',compact('Posts'));  
    }

    public function show($id)
    {
       $Post=\App\Post::find($id);

       return view('Post.post',compact('Post'));

    }
}
